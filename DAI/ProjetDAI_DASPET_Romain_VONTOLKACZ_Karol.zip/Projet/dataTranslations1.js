
const translations1 = [
  ['fr','Asperge','en','Asparagus'],
  ['ar','البرتقالي','fr','Orange'],
  ['en','Cauliflower','fr','Chou Fleur'],
  ['it','Pomodoro','es','Tomate'],
];
