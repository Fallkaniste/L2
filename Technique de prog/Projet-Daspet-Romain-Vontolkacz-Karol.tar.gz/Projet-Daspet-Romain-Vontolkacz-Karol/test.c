#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
int i;
int main(){
  char * command = malloc(sizeof(char*));
  char * arg = malloc(sizeof(char*));
  char
  command = "mvn salut";
do {
    printf("%c",command[i]);
    i++;
} while(command[i] != ' ');
printf("\n");
for (i = i+1; i < strlen(command); i++) {
  printf("%c", command[i]);
}


  return 0 ;
  printf("%s\n",arg );
}


do {
    command[i] = saisie[i];
    i++;
} while(saisie[i] != ' ');
i++;
for (j = 0; i < strlen(saisie)-1; j++) {

  arg[j] = saisie[i];
  i++;
}
